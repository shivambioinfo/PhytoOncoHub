# Methods (v0.1)

PhytoOncoHub is a transparent pre-screen.

- **cancer_prior** comes from a coarse literature band on the compound row.
- **target_fit** matches MW, aromaticity, H-bonds, and reported-target tags to a protein family (kinase, HDAC, ER, tubulin, …). PDB IDs are references only.
- **druglikeness** applies Lipinski/Veber-like cuts.
- **alerts** flag catechols, large polyphenols, quinones, and very large molecules.

Replace any score later with docking, MD, or measured cell-line IC50.
