# Publish PhytoOncoHub on GitHub

1. Create an empty public repo named `PhytoOncoHub` on github.com. Do not add a README there.
2. On your computer, open Terminal / PowerShell inside this folder.
3. Run:

```bash
git init
git add .
git commit -m "Initial release of PhytoOncoHub"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/PhytoOncoHub.git
git push -u origin main
```

4. On GitHub: gear next to About → paste the short description from the README → add topics.

There is no terminal inside the normal GitHub website. Use Terminal on your computer, or Code → Codespaces after the repo exists.
