from phytooncohub.engine import Engine


def test_egfr_screen_ranks_known_flavonoids():
    names = [hit["name"] for hit in Engine("egfr").screen()]
    assert "Quercetin" in names
    assert "Piperine" in names
    assert names.index("Quercetin") < names.index("Piperine")


def test_network_has_pathways():
    edges = Engine("egfr").network(top_n=2)
    assert edges
    assert "pathway" in edges[0]


def test_unknown_target_raises():
    try:
        Engine("not_a_target")
    except ValueError:
        return
    raise AssertionError("expected ValueError")
