from __future__ import annotations

import csv
from pathlib import Path


def screen_markdown(hits: list[dict], title: str) -> str:
    if not hits:
        return f"# {title}\n\nNo hits.\n"
    first = hits[0]
    lines = [
        f"# {title}",
        "",
        f"- Target: **{first['target_name']}** (`{first['target_key']}`, PDB {first['target_pdb']})",
        f"- Pathway / hallmark: {first['pathway']} / {first['hallmark']}",
        f"- Compounds scored: {len(hits)}",
        "",
        "> In silico pre-screen only. Not a cancer treatment predictor.",
        "",
        "| rank | name | class | prior | target | like | alerts | score |",
        "| ---: | --- | --- | ---: | ---: | ---: | --- | ---: |",
    ]
    for i, row in enumerate(hits, 1):
        lines.append(
            f"| {i} | {row['name']} | {row['class']} | {row['cancer_prior_score']} | "
            f"{row['target_score']} | {row['druglikeness']} | {row['alerts']} | **{row['rank_score']}** |"
        )
    return "\n".join(lines) + "\n"


def network_markdown(edges: list[dict]) -> str:
    lines = [
        "# PhytoOncoHub compound–target–pathway network",
        "",
        "| compound | target | PDB | pathway | hallmark | score |",
        "| --- | --- | --- | --- | --- | ---: |",
    ]
    for edge in edges:
        lines.append(
            f"| {edge['compound']} | {edge['target']} | {edge['pdb']} | "
            f"{edge['pathway']} | {edge['hallmark']} | {edge['rank_score']} |"
        )
    return "\n".join(lines) + "\n"


def write_csv(rows: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    cleaned = [{k: v for k, v in row.items() if k is not None} for row in rows]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=list(cleaned[0].keys()), extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(cleaned)
