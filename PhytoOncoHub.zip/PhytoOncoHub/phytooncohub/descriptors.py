from __future__ import annotations

from dataclasses import asdict, dataclass

try:
    from rdkit import Chem
    from rdkit.Chem import Crippen, Descriptors, rdMolDescriptors

    _RDKIT = True
except Exception:
    _RDKIT = False


@dataclass
class Desc:
    mw: float
    logp: float
    tpsa: float
    hbd: int
    hba: int
    rotatable: int
    rings: int
    arom_rings: int
    phenol_oh: int
    catechol: int
    carboxylic: int
    source: str

    def as_dict(self) -> dict:
        return asdict(self)


def from_smiles(smiles: str) -> Desc:
    if _RDKIT:
        mol = Chem.MolFromSmiles(smiles)
        if mol is not None:
            return Desc(
                mw=Descriptors.MolWt(mol),
                logp=Crippen.MolLogP(mol),
                tpsa=Descriptors.TPSA(mol),
                hbd=Descriptors.NumHDonors(mol),
                hba=Descriptors.NumHAcceptors(mol),
                rotatable=Descriptors.NumRotatableBonds(mol),
                rings=rdMolDescriptors.CalcNumRings(mol),
                arom_rings=rdMolDescriptors.CalcNumAromaticRings(mol),
                phenol_oh=len(mol.GetSubstructMatches(Chem.MolFromSmarts("[c][OH]"))),
                catechol=len(mol.GetSubstructMatches(Chem.MolFromSmarts("[c]([OH])[c][OH]"))),
                carboxylic=len(mol.GetSubstructMatches(Chem.MolFromSmarts("[CX3](=O)[OX2H1]"))),
                source="rdkit",
            )

    text = smiles or ""
    n_c = text.count("C") + text.count("c")
    n_o = text.count("O") + text.count("o")
    n_n = text.count("N") + text.count("n")
    return Desc(
        mw=12 * n_c + 16 * n_o + 14 * n_n + 10,
        logp=round(0.25 * n_c - 0.45 * n_o, 2),
        tpsa=float(20 * n_o + 12 * n_n),
        hbd=text.count("O") + text.count("N"),
        hba=n_o + n_n,
        rotatable=max(text.count("CC") // 3, 0),
        rings=max((text.count("1") + text.count("2")) // 2, 0),
        arom_rings=1 if "c" in text else 0,
        phenol_oh=min(n_o, 8),
        catechol=1 if "c(O)c(O)" in text else 0,
        carboxylic=1 if "C(=O)O" in text or "O=C(O)" in text else 0,
        source="heuristic",
    )
