"""Transparent pre-screen scores. Not docking ΔG and not a clinical predictor."""

from __future__ import annotations

from dataclasses import dataclass

from .descriptors import Desc


PRIOR = {"high": 82, "medium": 60, "low": 38, "": 50}

FAMILY_RULES = {
    "kinase": {"mw_lo": 220, "mw_hi": 550, "want_arom": True, "want_hbond": True},
    "lipid_kinase": {"mw_lo": 250, "mw_hi": 600, "want_arom": True, "want_hbond": True},
    "ppi": {"mw_lo": 280, "mw_hi": 700, "want_arom": True, "want_hbond": False},
    "atpase": {"mw_lo": 250, "mw_hi": 550, "want_arom": True, "want_hbond": True},
    "metalloenzyme": {"mw_lo": 150, "mw_hi": 450, "want_arom": False, "want_hbond": True},
    "nhr": {"mw_lo": 220, "mw_hi": 500, "want_arom": True, "want_hbond": False},
    "oxygenase": {"mw_lo": 180, "mw_hi": 450, "want_arom": True, "want_hbond": True},
    "cytoskeleton": {"mw_lo": 300, "mw_hi": 900, "want_arom": True, "want_hbond": False},
}


def clip(value: float) -> float:
    return max(0.0, min(100.0, value))


def cancer_prior(row: dict) -> float:
    score = float(PRIOR.get((row.get("cancer_prior") or "").lower(), 50))
    cls = (row.get("class") or "").lower()
    if cls in {"flavonoid", "isoflavonoid", "catechin", "polyphenol", "stilbene"}:
        score += 6
    if cls in {"taxane"}:
        score += 10
    return clip(score)


def target_score(row: dict, desc: Desc, target: dict) -> float:
    rules = FAMILY_RULES.get(target.get("family", ""), {"mw_lo": 150, "mw_hi": 700})
    score = 42.0
    if rules["mw_lo"] <= desc.mw <= rules["mw_hi"]:
        score += 16
    else:
        score -= 12
    reported = (row.get("reported_targets") or "").lower()
    key_hints = {
        "egfr": "egfr",
        "her2": "egfr",
        "vegfr2": "vegfr",
        "pi3k": "pi3k",
        "akt1": "akt",
        "mtor": "mtor",
        "braf": "braf",
        "cdk6": "cdk",
        "bcl2": "bcl",
        "top2a": "top",
        "hdac2": "hdac",
        "er_alpha": "er",
        "cox2": "cox",
        "tubulin": "tubulin",
    }
    # caller passes target key via extra field if present
    tkey = target.get("_key", "")
    hint = key_hints.get(tkey, tkey)
    if hint and hint in reported:
        score += 18
    if rules.get("want_arom") and desc.arom_rings >= 2:
        score += 8
    if rules.get("want_hbond") and desc.hbd >= 2 and desc.hba >= 4:
        score += 8
    if target.get("family") == "metalloenzyme" and (desc.catechol or desc.carboxylic):
        score += 10
    if target.get("family") == "nhr" and 2.0 <= desc.logp <= 5.5:
        score += 8
    return clip(score)


def druglikeness(desc: Desc) -> tuple[float, list[str]]:
    flags = []
    score = 100.0
    if desc.mw > 500:
        flags.append("MW>500")
        score -= 18
    if desc.logp > 5:
        flags.append("logP>5")
        score -= 14
    if desc.hbd > 5:
        flags.append("HBD>5")
        score -= 12
    if desc.hba > 10:
        flags.append("HBA>10")
        score -= 12
    if desc.rotatable > 10:
        flags.append("rotors>10")
        score -= 10
    if desc.tpsa > 140:
        flags.append("TPSA>140")
        score -= 10
    return clip(score), flags


def alert_score(row: dict, desc: Desc) -> tuple[float, list[str]]:
    """Soft safety / developability flags. Not a toxicity model."""
    alerts = []
    score = 80.0
    cls = (row.get("class") or "").lower()
    if desc.catechol:
        alerts.append("catechol_redox")
        score -= 8
    if desc.phenol_oh >= 6:
        alerts.append("polyphenol_assay_interference")
        score -= 8
    if cls == "quinone" or cls == "anthraquinone":
        alerts.append("quinone_reactivity")
        score -= 10
    if desc.mw > 800:
        alerts.append("very_large")
        score -= 15
    if "paclitaxel" in (row.get("id") or ""):
        alerts.append("injectable_natural_product_ref")
    return clip(score), alerts


@dataclass
class Weights:
    prior: float = 0.28
    target: float = 0.32
    like: float = 0.25
    alert: float = 0.15


def rank_score(prior: float, target: float, like: float, alert: float, weights: Weights | None = None) -> float:
    weights = weights or Weights()
    return clip(
        weights.prior * prior
        + weights.target * target
        + weights.like * like
        + weights.alert * alert
    )
