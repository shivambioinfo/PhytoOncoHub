from __future__ import annotations

from typing import Any

from .catalog import load_library, load_pathways, load_targets
from .descriptors import from_smiles
from .scoring import (
    Weights,
    alert_score,
    cancer_prior,
    druglikeness,
    rank_score,
    target_score,
)


class Engine:
    def __init__(self, target: str = "egfr", weights: Weights | None = None):
        self.target_key = target
        self.targets = load_targets()
        self.pathways = load_pathways()
        self.weights = weights or Weights()
        if target not in self.targets:
            raise ValueError(f"Unknown target '{target}'. Choose from: {sorted(self.targets)}")

    def score_row(self, row: dict[str, Any], target_key: str | None = None) -> dict[str, Any]:
        key = target_key or self.target_key
        target = dict(self.targets[key])
        target["_key"] = key
        desc = from_smiles(row["smiles"])
        prior = cancer_prior(row)
        tscore = target_score(row, desc, target)
        like, like_flags = druglikeness(desc)
        alert, alerts = alert_score(row, desc)
        out = dict(row)
        out.update(desc.as_dict())
        out.update(
            {
                "target_key": key,
                "target_name": target["name"],
                "target_pdb": target["pdb"],
                "pathway": target["pathway"],
                "hallmark": target["hallmark"],
                "cancer_prior_score": round(prior, 1),
                "target_score": round(tscore, 1),
                "druglikeness": round(like, 1),
                "alert_score": round(alert, 1),
                "lipinski_flags": ";".join(like_flags) or "none",
                "alerts": ";".join(alerts) or "none",
                "rank_score": round(rank_score(prior, tscore, like, alert, self.weights), 1),
            }
        )
        return out

    def screen(self, rows: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
        rows = rows if rows is not None else load_library()
        scored = [self.score_row(row) for row in rows]
        scored.sort(key=lambda item: item["rank_score"], reverse=True)
        return scored

    def network(self, rows: list[dict[str, Any]] | None = None, top_n: int = 3) -> list[dict[str, Any]]:
        """Compound–target–pathway edges for a simple network table."""
        rows = rows if rows is not None else load_library()
        edges = []
        for row in rows:
            per_target = [self.score_row(row, key) for key in self.targets]
            per_target.sort(key=lambda item: item["rank_score"], reverse=True)
            for hit in per_target[:top_n]:
                edges.append(
                    {
                        "compound": hit["name"],
                        "class": hit["class"],
                        "target": hit["target_key"],
                        "pdb": hit["target_pdb"],
                        "pathway": hit["pathway"],
                        "hallmark": hit["hallmark"],
                        "rank_score": hit["rank_score"],
                        "druglikeness": hit["druglikeness"],
                    }
                )
        edges.sort(key=lambda item: item["rank_score"], reverse=True)
        return edges
