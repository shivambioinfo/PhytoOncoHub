from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from .io import data_dir


def load_library(path: Path | None = None) -> list[dict[str, Any]]:
    path = path or data_dir() / "phytochemicals.csv"
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def load_targets(path: Path | None = None) -> dict[str, Any]:
    path = path or data_dir() / "targets.json"
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def load_pathways(path: Path | None = None) -> dict[str, Any]:
    path = path or data_dir() / "pathways.json"
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)
