from pathlib import Path


def data_dir() -> Path:
    here = Path(__file__).resolve().parent
    for candidate in (here.parent / "data", Path.cwd() / "data"):
        if candidate.exists():
            return candidate
    raise FileNotFoundError("Cannot find data/. Run from the repo root.")
