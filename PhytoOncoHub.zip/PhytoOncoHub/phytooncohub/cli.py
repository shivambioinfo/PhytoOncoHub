from __future__ import annotations

import argparse
import json
from pathlib import Path

from .catalog import load_library, load_targets
from .engine import Engine
from .report import network_markdown, screen_markdown, write_csv


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="phytooncohub",
        description="Rank phytochemicals against cancer protein targets with ADMET-style flags.",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    catalog = sub.add_parser("catalog", help="List compounds or targets")
    catalog.add_argument("--kind", choices=["phytos", "targets"], required=True)

    screen = sub.add_parser("screen", help="Score the library against one target")
    screen.add_argument("--target", default="egfr")
    screen.add_argument("--out", default="reports/screen.md")
    screen.add_argument("--top", type=int, default=0)

    score = sub.add_parser("score", help="Score one custom SMILES")
    score.add_argument("--name", required=True)
    score.add_argument("--smiles", required=True)
    score.add_argument("--class-name", default="unknown")
    score.add_argument("--target", default="egfr")

    net = sub.add_parser("network", help="Build compound-target-pathway edges")
    net.add_argument("--top-per-compound", type=int, default=3)
    net.add_argument("--out", default="reports/network.md")

    args = parser.parse_args(argv)

    if args.cmd == "catalog":
        if args.kind == "targets":
            for key, value in load_targets().items():
                print(f"{key:12} {value['pdb']:6} {value['pathway']:16} {value['name']}")
        else:
            for row in load_library():
                print(f"{row['id']:16} {row['class']:16} {row['name']}")
        return 0

    if args.cmd == "score":
        engine = Engine(args.target)
        row = {
            "id": args.name.lower().replace(" ", "_"),
            "name": args.name,
            "class": args.class_name,
            "plant": "custom",
            "smiles": args.smiles,
            "cancer_prior": "",
            "reported_targets": "",
            "notes": "user-supplied",
        }
        hit = engine.score_row(row)
        keep = [
            "name",
            "target_key",
            "target_pdb",
            "pathway",
            "cancer_prior_score",
            "target_score",
            "druglikeness",
            "alert_score",
            "lipinski_flags",
            "alerts",
            "rank_score",
            "mw",
            "logp",
            "source",
        ]
        print(json.dumps({key: hit[key] for key in keep}, indent=2))
        return 0

    if args.cmd == "network":
        engine = Engine("egfr")
        edges = engine.network(top_n=args.top_per_compound)
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(network_markdown(edges), encoding="utf-8")
        write_csv(edges, out.with_suffix(".csv"))
        print(f"Wrote {out} ({len(edges)} edges)")
        return 0

    engine = Engine(args.target)
    hits = engine.screen()
    if args.top:
        hits = hits[: args.top]
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(screen_markdown(hits, f"PhytoOncoHub screen — {args.target}"), encoding="utf-8")
    write_csv(hits, out.with_suffix(".csv"))
    print(f"Wrote {out}")
    print("Top 5:")
    for i, row in enumerate(hits[:5], 1):
        print(f"  {i}. {row['name']:24} score={row['rank_score']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
