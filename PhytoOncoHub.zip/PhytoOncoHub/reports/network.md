# PhytoOncoHub compound–target–pathway network

| compound | target | PDB | pathway | hallmark | score |
| --- | --- | --- | --- | --- | ---: |
| Curcumin | egfr | 1M17 | proliferation | sustaining proliferative signaling | 91.1 |
| Curcumin | her2 | 3PP0 | proliferation | sustaining proliferative signaling | 91.1 |
| Curcumin | akt1 | 3O96 | pi3k_akt_mtor | resisting cell death | 91.1 |
| Genistein | egfr | 1M17 | proliferation | sustaining proliferative signaling | 91.1 |
| Genistein | her2 | 3PP0 | proliferation | sustaining proliferative signaling | 91.1 |
| Genistein | akt1 | 3O96 | pi3k_akt_mtor | resisting cell death | 91.1 |
| Quercetin | pi3k | 4JPS | pi3k_akt_mtor | sustaining proliferative signaling | 89.9 |
| Quercetin | akt1 | 3O96 | pi3k_akt_mtor | resisting cell death | 89.9 |
| Quercetin | cdk6 | 5L2I | cell_cycle | evading growth suppressors | 89.9 |
| Luteolin | egfr | 1M17 | proliferation | sustaining proliferative signaling | 89.9 |
| Luteolin | her2 | 3PP0 | proliferation | sustaining proliferative signaling | 89.9 |
| Luteolin | vegfr2 | 4AG8 | angiogenesis | inducing angiogenesis | 89.9 |
| Resveratrol | cox2 | 5KIR | inflammation | tumor-promoting inflammation | 88.5 |
| Berberine | cdk6 | 5L2I | cell_cycle | evading growth suppressors | 86.8 |
| Berberine | top2a | 1ZXM | genome_integrity | genome instability and mutation | 86.8 |
| Resveratrol | er_alpha | 3ERT | hormone | sustaining proliferative signaling | 85.3 |
| Kaempferol | cdk6 | 5L2I | cell_cycle | evading growth suppressors | 84.9 |
| Kaempferol | er_alpha | 3ERT | hormone | sustaining proliferative signaling | 84.9 |
| Apigenin | cdk6 | 5L2I | cell_cycle | evading growth suppressors | 84.9 |
| Apigenin | er_alpha | 3ERT | hormone | sustaining proliferative signaling | 84.9 |
| Wogonin | cdk6 | 5L2I | cell_cycle | evading growth suppressors | 84.9 |
| Baicalein | hdac2 | 4LXZ | epigenetic | enabling replicative immortality | 84.4 |
| Baicalein | pi3k | 4JPS | pi3k_akt_mtor | sustaining proliferative signaling | 83.7 |
| Berberine | er_alpha | 3ERT | hormone | sustaining proliferative signaling | 83.6 |
| Resveratrol | egfr | 1M17 | proliferation | sustaining proliferative signaling | 82.8 |
| Ellagic acid | egfr | 1M17 | proliferation | sustaining proliferative signaling | 81.2 |
| Ellagic acid | her2 | 3PP0 | proliferation | sustaining proliferative signaling | 81.2 |
| Ellagic acid | vegfr2 | 4AG8 | angiogenesis | inducing angiogenesis | 81.2 |
| Withaferin A | tubulin | 1SA0 | mitosis | evading growth suppressors | 80.8 |
| Epigallocatechin gallate | egfr | 1M17 | proliferation | sustaining proliferative signaling | 80.2 |
| Epigallocatechin gallate | her2 | 3PP0 | proliferation | sustaining proliferative signaling | 80.2 |
| Epigallocatechin gallate | vegfr2 | 4AG8 | angiogenesis | inducing angiogenesis | 80.2 |
| Kaempferol | egfr | 1M17 | proliferation | sustaining proliferative signaling | 79.2 |
| Apigenin | egfr | 1M17 | proliferation | sustaining proliferative signaling | 79.2 |
| Wogonin | egfr | 1M17 | proliferation | sustaining proliferative signaling | 79.2 |
| Wogonin | her2 | 3PP0 | proliferation | sustaining proliferative signaling | 79.2 |
| Baicalein | egfr | 1M17 | proliferation | sustaining proliferative signaling | 78.0 |
| Withaferin A | egfr | 1M17 | proliferation | sustaining proliferative signaling | 77.6 |
| Withaferin A | her2 | 3PP0 | proliferation | sustaining proliferative signaling | 77.6 |
| Paclitaxel | tubulin | 1SA0 | mitosis | evading growth suppressors | 77.4 |
| Myricetin | pi3k | 4JPS | pi3k_akt_mtor | sustaining proliferative signaling | 77.0 |
| Myricetin | akt1 | 3O96 | pi3k_akt_mtor | resisting cell death | 77.0 |
| Gallic acid | hdac2 | 4LXZ | epigenetic | enabling replicative immortality | 76.5 |
| Emodin | egfr | 1M17 | proliferation | sustaining proliferative signaling | 76.0 |
| Emodin | her2 | 3PP0 | proliferation | sustaining proliferative signaling | 76.0 |
| Emodin | vegfr2 | 4AG8 | angiogenesis | inducing angiogenesis | 76.0 |
| Myricetin | hdac2 | 4LXZ | epigenetic | enabling replicative immortality | 71.9 |
| Piperine | er_alpha | 3ERT | hormone | sustaining proliferative signaling | 68.8 |
| Piperine | egfr | 1M17 | proliferation | sustaining proliferative signaling | 66.2 |
| Piperine | her2 | 3PP0 | proliferation | sustaining proliferative signaling | 66.2 |
| Paclitaxel | egfr | 1M17 | proliferation | sustaining proliferative signaling | 65.2 |
| Paclitaxel | her2 | 3PP0 | proliferation | sustaining proliferative signaling | 65.2 |
| Lycopene | egfr | 1M17 | proliferation | sustaining proliferative signaling | 61.9 |
| Lycopene | her2 | 3PP0 | proliferation | sustaining proliferative signaling | 61.9 |
| Lycopene | vegfr2 | 4AG8 | angiogenesis | inducing angiogenesis | 61.9 |
| Gallic acid | egfr | 1M17 | proliferation | sustaining proliferative signaling | 58.6 |
| Gallic acid | her2 | 3PP0 | proliferation | sustaining proliferative signaling | 58.6 |
