# PhytoOncoHub screen — egfr

- Target: **EGFR kinase** (`egfr`, PDB 1M17)
- Pathway / hallmark: proliferation / sustaining proliferative signaling
- Compounds scored: 19

> In silico pre-screen only. Not a cancer treatment predictor.

| rank | name | class | prior | target | like | alerts | score |
| ---: | --- | --- | ---: | ---: | ---: | --- | ---: |
| 1 | Curcumin | polyphenol | 88.0 | 92.0 | 100.0 | none | **91.1** |
| 2 | Genistein | isoflavonoid | 88.0 | 92.0 | 100.0 | none | **91.1** |
| 3 | Luteolin | flavonoid | 88.0 | 92.0 | 100.0 | catechol_redox | **89.9** |
| 4 | Quercetin | flavonoid | 88.0 | 74.0 | 100.0 | catechol_redox | **84.1** |
| 5 | Resveratrol | stilbene | 88.0 | 66.0 | 100.0 | none | **82.8** |
| 6 | Ellagic acid | polyphenol | 66.0 | 92.0 | 90.0 | catechol_redox | **81.2** |
| 7 | Berberine | alkaloid | 82.0 | 66.0 | 100.0 | none | **81.1** |
| 8 | Epigallocatechin gallate | catechin | 88.0 | 92.0 | 66.0 | catechol_redox;polyphenol_assay_interference | **80.2** |
| 9 | Kaempferol | flavonoid | 66.0 | 74.0 | 100.0 | none | **79.2** |
| 10 | Apigenin | flavonoid | 66.0 | 74.0 | 100.0 | none | **79.2** |
| 11 | Wogonin | flavonoid | 66.0 | 74.0 | 100.0 | none | **79.2** |
| 12 | Baicalein | flavonoid | 66.0 | 74.0 | 100.0 | catechol_redox | **78.0** |
| 13 | Withaferin A | withanolide | 82.0 | 66.0 | 86.0 | none | **77.6** |
| 14 | Emodin | anthraquinone | 60.0 | 74.0 | 100.0 | quinone_reactivity | **76.0** |
| 15 | Myricetin | flavonoid | 66.0 | 74.0 | 78.0 | catechol_redox;polyphenol_assay_interference | **71.3** |
| 16 | Piperine | alkaloid | 38.0 | 58.0 | 100.0 | none | **66.2** |
| 17 | Paclitaxel | taxane | 92.0 | 46.0 | 60.0 | very_large;injectable_natural_product_ref | **65.2** |
| 18 | Lycopene | carotenoid | 60.0 | 58.0 | 58.0 | none | **61.9** |
| 19 | Gallic acid | phenolic_acid | 38.0 | 38.0 | 100.0 | catechol_redox | **58.6** |
