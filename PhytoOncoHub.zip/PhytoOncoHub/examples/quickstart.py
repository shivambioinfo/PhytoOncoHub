from phytooncohub import Engine, load_library

engine = Engine(target="egfr")
hits = engine.screen(load_library())
print(f"{'rank':<6}{'name':<24}{'score':>8}{'like':>8}{'target':>8}")
for i, hit in enumerate(hits[:8], 1):
    print(f"{i:<6}{hit['name']:<24}{hit['rank_score']:>8}{hit['druglikeness']:>8}{hit['target_score']:>8}")
